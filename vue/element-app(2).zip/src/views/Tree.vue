<template>
    <div id="outterContainer">
        <header id="myHeader">
            <span id="title">百度脑图2.1</span>
        </header>
        <div id="myContainer">
            <Search @changeTree="changeTree"></Search>
            <el-container>
                <el-aside width="35%">
                    <div id="leftTop">
                        <div class="myHeader">
                            Props
                        </div>
                        <div class="content">
                            <div class="block">
                                <span>type</span>
                                <el-select v-model="treeData.type" placeholder="请选择">
                                    <el-option
                                            v-for="item in typeOptions"
                                            :key="item.value"
                                            :label="item.label"
                                            :value="item.value">
                                    </el-option>
                                </el-select>
                            </div>
                            <div class="block">
                                <span>layoutType</span>
                                <el-select v-model="treeData.layoutType" placeholder="请选择">
                                    <el-option
                                            v-for="item in layoutTypeOptions"
                                            :key="item.value"
                                            :label="item.label"
                                            :value="item.value">
                                    </el-option>
                                </el-select>
                            </div>
                            <div class="block">
                                <span>marginx(px)</span>
                                <el-slider
                                        :max="200"
                                        v-model="treeData.marginx"
                                        >
                                </el-slider>
                            </div>
                            <div class="block">
                                <span>marginy(px)</span>
                                <el-slider
                                        :max="200"
                                        v-model="treeData.marginy"
                                        >
                                </el-slider>
                            </div>
                            <div class="block">
                                <span>radius(px)</span>
                                <el-slider
                                        :max="10"
                                        v-model="treeData.radius"
                                        >
                                </el-slider>
                            </div>
                            <div class="block">
                                <span>Duration(ms)</span>
                                <el-slider
                                        :max="3000"
                                        v-model="treeData.duration"
                                        >
                                </el-slider>
                            </div>
                        </div>
                    </div>
                    <div id="leftBottom">
                        <div class="myHeader">
                            Image
                        </div>
                        <div class="content">
                            <img :src="imgSrc" v-show="showImg"/>
                        </div>
                    </div>
                </el-aside>
                <el-main>
                    <tree
                            :data="treeData.tree"
                            node-text="name"
                            :layoutType="treeData.layoutType"
                            :marginX="treeData.marginx"
                            :marginY="treeData.marginy"
                            :duration="treeData.duration"
                            :type="treeData.type"
                            :radius="treeData.radius"
                            @clicked="clickNode"
                            id="myTree">
                    </tree>
                </el-main>
            </el-container>
        </div>
    </div>
</template>

<script>
    import {tree} from 'vued3tree'
    import Search from '../components/Search'

    export default {
        name: 'app',
        components: {
            tree,
            Search
        },
        data() {
            return {
                typeOptions: [{
                    value: 'tree',
                    label: 'tree'
                }, {
                    value: 'cluster',
                    label: 'cluster'
                }],
                layoutTypeOptions: [{
                    value: 'circular',
                    label: 'circular'
                }, {
                    value: 'euclidean',
                    label: 'euclidean'
                }],
                treeData: {
                    tree: {},
                    marginx: 20,
                    marginy: 20,
                    type: 'tree',
                    layoutType: 'euclidean',
                    radius: 3,
                    duration: 750
                },
                imgSrc: '',
                currentImg: '',
                showImg: false
            }
        },
        methods: {
            clickNode: function (node) {
                let current = `${node["data"]["name"]} (${node["data"]["time"]})`
                if (this.showImg && this.currentImg === current) {
                    this.showImg = false;
                } else {
                    this.currentImg = current;
                    this.imgSrc = node["data"]["proof"];
                    this.showImg = true;
                }
            },
            changeTree: function (newTree) {
                this.treeData.tree = newTree;
                this.showImg = false;
            }
        },
        mounted() {
            const context = this;
            fetch(`http://localhost:7000/test_api/2/开始/`, {
                headers:{
                    'content-type':'application/json'
                }
            }).then(function(response){
                    response.json().then(function(response) {
                        context.treeData.tree = response[0]["Graph"]["tree"];
                    });
                }
            );
        }
    }
</script>

<style lang="scss">
    @import '../style/reset.css';
    body {
        background-color: #f4f5f5;
        background-image: url("../assets/background.png");
    }
    body::-webkit-scrollbar {
        display:none
    }
    .el-container {
        width: 1300px;
        margin-bottom: 30px;
    }

    .el-main {
        background-color: #ffffff;
        border: 1px solid #e1e1e1;
        border-radius: 5px;
        margin-left: 20px;
    }

    .el-aside {
        #leftTop, #leftBottom {
            background-color: #ffffff;
            border: 1px solid #e1e1e1;
            border-radius: 5px;
            margin-bottom: 30px;
            .myHeader {
                background-color: #f8f8f8;
                height: 45px;
                line-height: 45px;
                border-bottom: 1px solid #e1e1e1;
                text-align: center;
            }
            .content {
                padding: 20px 20px 40px 20px;
                img {
                    width: 100%;
                }
                .block {
                    margin: 10px 0;
                    display: flex;
                    span {
                        padding: 10px 0;
                        text-align: right;
                        width: 135px;
                        margin-right: 10px;
                        font-weight: 600;
                    }
                    .el-slider {
                        width: 100%;
                    }
                }
                .el-select {
                    width: 100%;
                }
            }
        }
    }
    #myHeader {
        text-align: center;
        z-index: 1000;
        position: fixed;
        width: 100%;
        height: 60px;
        background-color: #ffffff;
        border-bottom: 1px solid #e1e1e1;
        line-height: 60px;
        #title {
            display: inline-block;
            font-family: "等线";
            font-size: 40px;
            font-weight: bolder;
            color: #70e1bd;
        }
    }
    #myContainer {
        padding-top: 80px;
        padding-left: 5%;
    }
    #myTree {
        height: 800px;
        width: 1000px;
    }
</style>
